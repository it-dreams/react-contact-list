import React from 'react';
import userPic from '../../assets/img/user.png';


function ContactCard(props) {
    const {id, name, email} = props.contact; //destructure

    return (
        <div className="item">
            <img className='ui avatar image' src={userPic} alt="Avatar" />
            
            <div className="content">
                <div className="header">{name}</div>
                <div>{email}</div>
            </div>
            
            <i className="trash alternate outline icon" style={{color: "red", marginTop: "7px", float: "right"}}></i>
        </div>
    );
}

export default ContactCard;