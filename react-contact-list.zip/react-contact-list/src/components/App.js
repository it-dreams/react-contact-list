import React, { useState, useEffect } from 'react';
import '../assets/css/App.css';

import Header from './shared/Header';
import AddContact from './pages/AddContact';
import ContactList from './pages/ContactList';

function App() {
  const LOCAL_STORAGE_KEY = "contacts";
  const [contacts, setContacts] = useState([]);

  const addContactHandler = (contact) => {
    console.log(contact);
    setContacts([...contacts, contact]);
  };

  useEffect(() => {
    const retriveContacts = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY));  // fetch data from localstorage
    if(retriveContacts) setContacts(retriveContacts);  
  }, []);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(contacts));  // add data to localstorage
  }, [contacts]);

  // const contacts = [
  //   {
  //     id: '1',
  //     name: 'Rahul',
  //     email: 'rahul@gmail.com'
  //   },
  //   {
  //     id: '2',
  //     name: 'Raj',
  //     email: 'raj@gmail.com'
  //   },
  //   {
  //     id: '3',
  //     name: 'Amit',
  //     email: 'amit@gmail.com'
  //   }
  // ];

  return (
    <div className='ui container'>
      <Header />
      <AddContact addContactHandler={addContactHandler} />
      <ContactList contacts = {contacts} />
    </div>
  );
}

export default App;
