1. SEO for SEA
2. Product linking from recipe in SEA
   - sg - Done
   - my - Done
   - th - Done
   - id - Done
   - ph - Done


# Products urls

